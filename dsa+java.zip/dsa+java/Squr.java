//perimeter of rectangle
import java.util.Scanner;
class Squr{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int side=sc.nextInt();
        int perimeter=4*side;
        System.out.println("The perimeter of the square is:"+perimeter);
    }
}