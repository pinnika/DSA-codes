class maps{
    public static void main(String[] args){
        //Stack<Integer> s=new Stack<>();
        //HashMap<String,Integer> map=new HashMap<>();
        
        System.out.println(gcd(2,4));
        add(1,2);
    }
    public static void add(int a , int b){
        System.out.println(a+b);
    }
    private static int gcd(int a, int b){
        if(a==0) return b;
        return gcd(b%a,a);
    }

}