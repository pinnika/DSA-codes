import java.util.Scanner;
class Sum{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int i=1;
        int sum=0;
        for(i=1;i<=n;i++){
            System.out.println(i);
            sum=sum+i;

        }
        // while(i<=n){
        //     System.out.println(i);
        //     sum=sum+i;
        //     i++;
        // }
        System.out.println(sum);
    }
}