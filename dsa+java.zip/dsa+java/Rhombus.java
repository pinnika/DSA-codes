//Area of the Rhombus
import java.util.Scanner;
class Rhombus{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int diagonal_1=sc.nextInt();
        int diagonal_2=sc.nextInt();
        double area=0.5*diagonal_1*diagonal_2;
        System.out.println("The area of the rhombus is:"+area);

    }
}