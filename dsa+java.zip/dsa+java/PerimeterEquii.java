//perimeter of equilateral triangle
import java.util.Scanner;
class PerimeterEquii{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int side=sc.nextInt();
        int perimeter=3*side;
        System.out.println("The perimeter of the equilateral triangle is:"+perimeter);
    }
}