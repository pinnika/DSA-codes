//perimeter of the circle
import java.util.Scanner;
class PerimeterCicle{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int radius=sc.nextInt();
        double perimeter=2*3.14*radius;
        System.out.println("The perimeter of the circle is:"+perimeter);
    }
}