import java.util.Scanner;
class Prime{
public static void main(String[] args){
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
int c=2;
if(n==1){
    System.out.println("Neither Prime nor composite");
}
else{
    while(c*c<n){
if(n%c==0){
System.out.println("Not Prime");
return;
}
c=c+1;
}
if(c*c>n){
    System.out.println("Prime");
}
}
}
}