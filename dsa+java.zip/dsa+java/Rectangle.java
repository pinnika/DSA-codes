//Area of the rectangle
import java.util.Scanner;
class Rectangle{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int base=sc.nextInt();
        int height=sc.nextInt();
        int area=base*height;
        System.out.println("The area of the rectangle is:"+area);
    }
}