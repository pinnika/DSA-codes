import java.util.Scanner;
class Power{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int k=sc.nextInt();
        double result=Math.pow(n,k);
        System.out.println(result);
    }
}