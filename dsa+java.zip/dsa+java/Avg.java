import java.util.Scanner;
class Avg{
    public static void main(String[] args){
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        int sum=0;
        int average;
        for(int i=1;i<=n;i++){
            sum=sum+i;
        }
        average=sum/n;
        System.out.println(sum);
        System.out.println("the average od n numbers is:"+average);
    }
}