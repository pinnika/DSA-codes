import java.util.Scanner;
class OddOrEven{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        if(a%2==0){
            System.out.println("The given number is even");
        }
        else{
            System.out.println("The number is odd");
        }
    }
}