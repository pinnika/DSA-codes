//Area of the equilateral triangle
import java.util.Scanner;
class Equi{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int side=sc.nextInt();
        double area=Math.sqrt(3)*side*side*0.25;
        System.out.println("The area of the equilateral triangle is:"+area);
    }
}