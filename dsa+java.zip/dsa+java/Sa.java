class Sa{
    public static void main(String[] args) {
        int $=24;
        System.out.println($);
    }
}