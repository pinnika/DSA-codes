import java.util.Scanner;
class Square{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int side=sc.nextInt();
        System.out.println("The area of the square is:"+side*side);
    }
}