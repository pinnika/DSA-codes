//Area of the parallelogram
import java.util.Scanner;
class Parallelogram{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int base=sc.nextInt();
        int height=sc.nextInt();
        int area=base*height;
        System.out.println("The area of the Parallelogram is:"+area);
    }
}