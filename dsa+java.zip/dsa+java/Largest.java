import java.util.Scanner;
class Largest{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int b=sc.nextInt();
        if(a>b){
            System.out.println("a is greater than b");
        }
        else if(a==b){
            System.out.println("a and b are equal");
        }
        else{
            System.out.println("a is smaller than b");
        }
    }
}