import java.util.Scanner;
class Second{
public static void main(String[] args) {
    int a;
    int b;
    Scanner sc=new Scanner(System.in);
    a=sc.nextInt();
    b=sc.nextInt();
    int sum=a+b;
    System.out.println(sum);
}
}