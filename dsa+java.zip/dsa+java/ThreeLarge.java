import java.util.Scanner;
class ThreeLarge{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int b=sc.nextInt();
        int c=sc.nextInt();
        // if(a>b && a>c){
        //     System.out.println("a is greater than b and c");
        // }
        // else if(b>a && b>c){
        //     System.out.println("b is greater than a and c");
        // }
        // else if(c>a && c>b){
        //     System.out.println("c is greater than a and c");
        // }
        // else{
        //     System.out.println("a b and c are equal");
        // }
        String large=" ";
        large=(a>b && a>c) ? "A":(b>a && b>c) ? "B":(c>b && c>a) ? "C":"";
        System.out.println(large);

    }
}